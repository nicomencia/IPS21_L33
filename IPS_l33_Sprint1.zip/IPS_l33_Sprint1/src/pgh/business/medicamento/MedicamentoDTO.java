package pgh.business.medicamento;

public class MedicamentoDTO {

	public String idMedicamento;
	public String idPrescripcion;
	public int cantidad;
	public String intervalo;
	public String duracion;
	
}
