package pgh.business.historial;

public class HistorialDTO {

	public String idHistorial;
	public String idPaciente;
	
}
