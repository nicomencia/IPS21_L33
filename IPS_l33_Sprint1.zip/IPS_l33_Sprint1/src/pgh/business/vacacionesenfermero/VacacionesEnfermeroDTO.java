package pgh.business.vacacionesenfermero;

import java.util.Date;

public class VacacionesEnfermeroDTO {

	public String idVacacionesEnfermero;
	public String idEnfermero;
	public Date diaInicio;
	public Date diaFin;
	
}
