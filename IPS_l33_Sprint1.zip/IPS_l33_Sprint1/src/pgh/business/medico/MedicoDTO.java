package pgh.business.medico;

public class MedicoDTO {
	
	public String idMedico;
	public String nombre;
	public String apellidos;
	public String email;

}
