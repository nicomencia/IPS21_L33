package pgh.business.medicocita;

public class MedicoCitaDTO {
	
	public String idMedico;
	public String idCita;

}
