package pgh.business.prescripcion;

public class PrescripcionDTO {

	public String idPrescripcion;
	public String idPaciente;
	public String instruccion;
	public String horaAsignacion;
	public String diaAsignacion;
	
}
