package pgh.business.enfermero;

public class EnfermeroDTO {

	public String idEnfermero;
	public String nombre;
	public String apellidos;
	
}
