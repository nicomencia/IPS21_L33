package pgh.business.jornadamedico;

import java.util.Date;

public class JornadaMedicoDTO {

	public String idJornadaMedico;
	public String idMedico;
	public String dias;
	public Date diaInicio;
	public Date diaFin;
	public String horaInicio;
	public String horaFin;
	
}
