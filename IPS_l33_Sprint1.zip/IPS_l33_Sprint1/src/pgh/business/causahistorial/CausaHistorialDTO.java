package pgh.business.causahistorial;

public class CausaHistorialDTO {

	public String idCausa;
	public String idHistorial;
	
}
