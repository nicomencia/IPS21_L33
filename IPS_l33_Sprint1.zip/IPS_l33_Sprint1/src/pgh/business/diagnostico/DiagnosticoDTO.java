package pgh.business.diagnostico;

public class DiagnosticoDTO {

	public String idDiagnostico;
	public String idCita;
	public String descripcion;
	
}
