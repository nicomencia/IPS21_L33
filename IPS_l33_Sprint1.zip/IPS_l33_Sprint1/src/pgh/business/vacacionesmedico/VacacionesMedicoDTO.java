package pgh.business.vacacionesmedico;

import java.util.Date;

public class VacacionesMedicoDTO {

	public String idVacacionesMedico;
	public String idMedico;
	public Date diaInicio;
	public Date diaFin;
	
}
