package pgh.business.paciente;

public class PacienteDTO {
	
	public String idPaciente;
	public String dni;
	public String nombre;
	public String apellidos;
	public String email;
	public String telefono;

}
