package pgh.business.jornadaenfermero;

import java.util.Date;

public class JornadaEnfermeroDTO {

	public String idJornadaEnfermero;
	public String idEnfermero;
	public String dias;
	public Date diaInicio;
	public Date diaFin;
	public String horaInicio;
	public String horaFin;
	
}
