package pgh.business.cita;

import java.util.Date;

public class CitaDTO {
	
	public String idCita;
	public String idPaciente;
	public String idmedico;
	public Date fecha;
	public String horaInicio;
	public String horaFin;
	public String ubicacion;
	public boolean asistencia;
	
	

}
