package pgh.business.causa;

public class CausaDTO {

	public String idCausa;
	public String descripcion;
	
}
